main()
{
   printf("This is a line of text to output.");
}
