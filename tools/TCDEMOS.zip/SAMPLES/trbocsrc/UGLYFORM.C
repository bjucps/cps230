main()  /* Main program starts here */{printf("Good form ");printf
 ("can aid in ");printf("understanding a program.\n")
;printf("And bad form ");printf("can make a program ");
printf("unreadable.\n");}
