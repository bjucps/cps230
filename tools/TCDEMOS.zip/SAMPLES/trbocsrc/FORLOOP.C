                                          /* Chapter 3 - Program 3 */
/* This is an example of a for loop */

main()
{
int index;

   for(index = 0;index < 6;index = index + 1)
     printf("The value of the index is %d\n",index);
}
