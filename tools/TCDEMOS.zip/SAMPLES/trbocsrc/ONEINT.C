main()
{
int index;
   index = 13;
   printf("The value of the index is %d\n",index);
   index = 27;
   printf("The value of the index is %d\n",index);
   index = 10;
   printf("The value of the index is %d\n",index);
}
