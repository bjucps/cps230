       /* This is a comment ignored by the compiler */

main() /* This is another comment ignored by the compiler */
{
   printf("We are looking at how comments are "); /* A comment is
                                                     allowed to be
                                                     continued on
                                                     another line */
   printf("used in C.\n");
}
     /* One more comment for effect */
