/* -------- color.c ------- */

void ccolor(void);

main()
{
	ccolor();
}


