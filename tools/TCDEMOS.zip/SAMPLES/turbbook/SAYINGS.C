/* ------ sayings.c ------ */

#include "twindow.h"
void maxims(void);

main()
{
	load_help("tcprogs.hlp");
	maxims();
}

