int main() {
	chdir("TC");
	system("TC.EXE");
}